#include<stdio.h>
int main()
{
	int num1,num2;
	
	if(scanf("%d %d",&num1,&num2))
		printf("����ɹ���\n");
	else{
		printf("����ʧ��!\n"); 
	}
	
	/*if(2>1)
	{
		printf("yes");
		printf("Hello"); 
	}
	else if(3*2==6)
		printf("Yes");
	else 
		printf("No"); 
		*/
	int GirlfirendNum;
	scanf("%d",&GirlfirendNum);
	printf("%d",GirlfirendNum);
	/* 
	���е�Ů������ 
	*/ 
	 
	switch(GirlfirendNum/10)
	{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:printf("F");break;
		case 6:
		case 7:printf("D");break;
		case 8:printf("C");break;
		case 9:printf("B");break;
		case 10:printf("A");break;	
	}
	getchar();
	
	return 0;
 } 
 
 
 
 
